package kr.green.hotel.dao;

public interface MemberRoleDAO {
	void insert(String userid);
}
